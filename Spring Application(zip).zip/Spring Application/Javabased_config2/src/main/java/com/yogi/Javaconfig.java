package com.yogi;

import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Javaconfig {
	@Bean("id1")
	public StudBean getstud()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the id and name");
		int id=sc.nextInt();
		String name=sc.next();
		
		StudBean eb=new StudBean(id, name);
		return eb;
}

}
