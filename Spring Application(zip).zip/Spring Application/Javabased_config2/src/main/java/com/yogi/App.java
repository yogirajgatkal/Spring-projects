package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
       ApplicationContext ctx= new AnnotationConfigApplicationContext(Javaconfig.class);
       StudBean a =(StudBean)ctx.getBean("id2");
       a.print();
    }
}
