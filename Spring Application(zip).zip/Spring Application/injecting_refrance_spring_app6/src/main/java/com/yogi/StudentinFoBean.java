package com.yogi;

public class StudentinFoBean {
	private int sid;
	private String name;
	private AddressBean ob;
	public StudentinFoBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public AddressBean getOb() {
		return ob;
	}
	public void setOb(AddressBean ob) {
		this.ob = ob;
	}
	
	
    public void print()
    {
    	System.out.println("sid "+sid);
    	System.out.println("name "+name);
    	System.out.println(ob);
    }
}

