package com.yogi;

public class MarginBean {
	private int mrgid;
	private String mgrcode;
	public MarginBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public MarginBean(int mrgid, String mgrcode) {
		super();
		this.mrgid = mrgid;
		this.mgrcode = mgrcode;
	}


	@Override
	public String toString() {
		return "MarginBean [mrgid=" + mrgid + ", mgrcode=" + mgrcode + "]";
	}
	

}
