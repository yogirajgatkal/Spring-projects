package com.yogi;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       System.out.println("Hello");
       ApplicationContext ctx= new ClassPathXmlApplicationContext("spconfig.xml");
       ProductBean a =(ProductBean)ctx.getBean("id3");
       a.print();
    }
}

