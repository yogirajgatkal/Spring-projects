package com.yogi;

public class ModelBean {
	private int modelid;
	private String modelcode;
	private Double modelcost;
	private MarginBean mgob;
	public ModelBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public ModelBean(int modelid, String modelcode, Double modelcost, MarginBean mgob) {
		super();
		this.modelid = modelid;
		this.modelcode = modelcode;
		this.modelcost = modelcost;
		this.mgob = mgob;
	}


	@Override
	public String toString() {
		return "ModelBean [modelid=" + modelid + ", modelcode=" + modelcode + ", modelcost=" + modelcost + ", mgob="
				+ mgob + "]";
	}
	public void printModel()
	{
	System.out.println(modelid);
	System.out.println(modelcode);
	System.out.println(modelcost);
	System.out.println(mgob);
	}
	

}
