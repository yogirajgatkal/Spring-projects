package com.yogi;

public class ProductBean {
	private int prodid;
	private String prodname;
	private ModelBean mob;
	public ProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ProductBean(int prodid, String prodname, ModelBean mob) {
		super();
		this.prodid = prodid;
		this.prodname = prodname;
		this.mob = mob;
	}

	public void print()
	{
		System.out.print("product id "+prodid);
		System.out.print("product name "+prodname);
		System.out.print("model "+mob);
	}

}
