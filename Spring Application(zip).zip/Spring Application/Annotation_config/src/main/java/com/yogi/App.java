package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@Configuration
@ComponentScan("com yogi")
public class App 
{
    public static void main( String[] args )
    {
        
       ApplicationContext ctx= new AnnotationConfigApplicationContext(App.class);
       EmployeeBean a =(EmployeeBean)ctx.getBean("id1");
       CustomerBean c=(CustomerBean)ctx.getBean("id2");
       c.print();
    }
}
