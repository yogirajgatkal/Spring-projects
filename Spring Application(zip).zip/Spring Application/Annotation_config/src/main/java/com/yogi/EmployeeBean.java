package com.yogi;

import org.springframework.stereotype.Component;

@Component("id1")
public class EmployeeBean {
	public EmployeeBean()
	{
		System.out.println("hello hii");
	}

}
