package com.yogi;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("id2")
public class CustomerBean {
	@Value("101")
	private int cid;
	@Value("yogi")
	private String name;
	public CustomerBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void print()
	{
		System.out.println(cid);
		System.out.println(name);
	}

}
