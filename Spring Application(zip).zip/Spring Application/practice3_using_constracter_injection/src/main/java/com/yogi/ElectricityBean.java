package com.yogi;

public class ElectricityBean {
         private int cid;
         private String name;
         private Double p_reading;
         private Double c_reading;
         
		 public ElectricityBean(int cid, String name, Double p_reading, Double c_reading) {
			super();
			this.cid = cid;
			this.name = name;
			this.p_reading = p_reading;
			this.c_reading = c_reading;
		 }
		 
		 public void print()
		 {
			 Double tot=0.0;
			 Double unit=c_reading-p_reading;
			 if(unit<100)
			 {
				 tot=unit*1.75;
			 }
			 else if(unit>100 && unit<200)
			 {
				 tot=unit*2.75;
			 }
			 else if(unit>=200 && unit<300)
			 {
				 tot=unit*3.75;
			 }
			 else if(unit>300 && unit<400)
			 {
				 tot=unit*4.75;
			 }
			 else if(unit>400 && unit<500)
			 {
				 tot=unit*5.75;
			 }
			 else if(unit>500)
			 {
				 tot=unit*7.75;
			 }
			 System.out.println("id:- "+cid);
			 System.out.println("name:- "+name);
			 System.out.println("previous reading:- "+p_reading);
			 System.out.println("current reading:- "+c_reading);
			 System.out.println("total:- "+tot);
		 }
		 
         
         
}
