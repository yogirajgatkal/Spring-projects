package com.yogi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class javaconfig {
	@Bean("id3")
	public StudentBean getStudent()
	{
		List empprojects=new ArrayList();
		empprojects.add(10);
		empprojects.add(20);
		empprojects.add(30);
		empprojects.add(40);
		empprojects.add(50);
		
		Map<Integer, String> empmap=new HashMap();
		empmap.put(10, "tcs");
		empmap.put(20, "jio");
		empmap.put(30, "wipro");
		empmap.put(40, "infosys");
		
		StudentBean eb=new StudentBean("yogi",empprojects,empmap);
		return eb;
	}

}
