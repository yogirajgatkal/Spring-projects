package com.yogi;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class StudentBean {
	private String eid;
	private List<Integer> empprojects;
	private Map<Integer, String> empmap;
	
	
	
	public StudentBean(String eid, List<Integer> empprojects, Map<Integer, String> empmap) {
		super();
		this.eid = eid;
		this.empprojects = empprojects;
		this.empmap = empmap;
	}

	public void printempid()
	{
		System.out.println("empid "+eid);
	}
	
	 public void printprojects() 
	 { 
	  System.out.println("====STUDENT NAMES========"); 
	  for(Integer project:empprojects) 
	  { 
	   System.out.println(project); 
	  } 
	 } 
	 
	 public void print() 
	 { 
	  System.out.println("=====BARNCH DETAILS======="); 
	  for(Map.Entry<Integer,String > entry:empmap.entrySet()) 
	  { 
	   System.out.println(entry.getKey()+"\t"+entry.getValue()); 
	  } 
	 } 

}
