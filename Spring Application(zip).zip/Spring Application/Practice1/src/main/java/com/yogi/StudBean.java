package com.yogi;

public class StudBean {
		private Integer id;
		private String name;
		private Integer rollno;
		private String address;
		private String classname;
		public StudBean() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Integer getRollno() {
			return rollno;
		}
		public void setRollno(Integer rollno) {
			this.rollno = rollno;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getClassname() {
			return classname;
		}
		public void setClassname(String classname) {
			this.classname = classname;
		}
		@Override
		public String toString() {
			return "Stud [id=" + id + ", name=" + name + ", rollno=" + rollno + ", address=" + address + ", classname="
					+ classname + "]";
		}
		public void print()
		{
			System.out.println(id);
			System.out.println(name);
			System.out.println(rollno);
			System.out.println(address);
			System.out.println(classname);
		}
		
		
		
		
		
}
