package com.yogi;

import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentBean {
	private JdbcTemplate jt;

	public StudentBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	public void  createtable()
	{
		jt.execute("create table StudentBean(id number(10),sname varchar2(30),address varchar2(20))");
		System.out.println("new table created");
	}
	public void insertRecord()
	{
		int i=jt.update("insert into StudentBean values(103,'vishnu','jalna')");
		System.out.println(i+"new record inserted");
	}
	public void updateRecord()
	{
		int i=jt.update("update StudentBean set sname='yogiraj' where id=101");
		System.out.println(i+"record updated");
	}
	public void deleteRecord()
	{
		int i=jt.update("delete from StudentBean where id=103");
		System.out.println(i+"record deleted");
	}
	public void getallRecords()
	{
		List list=jt.queryForList("select * from StudentBean");
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Object o=it.next();
			System.out.println(o.toString());
		}
	}
	
	public void getoneRecords()
	{
		List list=jt.queryForList("select * from StudentBean where id=101");
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Object o=it.next();
			System.out.println(o.toString());
		}
	}
	

}
