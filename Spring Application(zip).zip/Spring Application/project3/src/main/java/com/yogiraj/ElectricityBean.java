package com.yogiraj;
	
public class ElectricityBean {
	private int id;
	private String name;
	private Double c_reading;
	private Double p_readinng;
	public ElectricityBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ElectricityBean(int id, String name, Double c_reading, Double p_readinng) {
		super();
		this.id = id;
		this.name = name;
		this.c_reading = c_reading;
		this.p_readinng = p_readinng;
	}

	@Override
	public String toString() {
		return "Electricity [id=" + id + ", name=" + name + ", c_reading=" + c_reading + ", p_readinng=" + p_readinng
				+ "]";
	}
	public void print()
	{
		Double total=0.0;
		Double unit=c_reading-p_readinng;
		if(unit<500)
		{
			total=unit*1.75;
			
		}
		else if(unit>500 && unit<700)
		{
			total=unit*5.27;
		}
		else 
		{
			total=unit*7.75;
		}
	}
	
	
	
}
