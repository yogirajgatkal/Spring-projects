package com.yogiraj;

import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SPConfig {
	
	@Bean("id1")
	public Emp empinfo() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name ");
		int id=sc.nextInt();
		String name=sc.next();
		
		
		
		Emp e1=new Emp(id,name);
		return e1;
	}

}
