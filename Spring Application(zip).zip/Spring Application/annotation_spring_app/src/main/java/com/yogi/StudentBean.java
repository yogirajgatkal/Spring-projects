package com.yogi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class StudentBean {
	private int sid;
	private String sname;
	@Autowired
	@Qualifier("temp_address")
	private AddressBean addr;
	
	public StudentBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public AddressBean getAddr() {
		return addr;
	}
	public void setAddr(AddressBean addr) {
		this.addr = addr;
	}
	public void print()
	{
		System.out.println("sid "+sid);
		System.out.println("name "+sname);
		System.out.println(addr);
	}

}
