package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       System.out.println("hello");
       ApplicationContext ctx= new ClassPathXmlApplicationContext("Spconfig.xml");
       StudentBean a =(StudentBean)ctx.getBean("id2");
       a.print();
    }
}
