package com.yogiraj;

public class AdditionBean {
		private int n1;
		private int n2;
		public AdditionBean() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getN1() {
			return n1;
		}
		public void setN1(int n1) {
			this.n1 = n1;
		}
		public int getN2() {
			return n2;
		}
		public void setN2(int n2) {
			this.n2 = n2;
		}
		public void print()
		{
			int add=n1+n2;
			System.out.println(add);
			
		}
		public void sub()
		{
			int sub=n1-n2;
			System.out.println(sub);
		}
		public void mul()
		{
			int mul=n1*n2;
			System.out.println(mul);
		}
		public void div()
		{
			int div=n1/n2;
			System.out.println(div);
		}
		
}
