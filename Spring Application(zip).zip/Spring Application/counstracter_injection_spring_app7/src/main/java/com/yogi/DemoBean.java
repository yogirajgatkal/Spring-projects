package com.yogi;

import java.util.List;

public class DemoBean {
	private int id;
	private String name;
	private String address;
	private List<Integer> mno;
	public DemoBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DemoBean(int id, String name, String address, List<Integer> mno) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.mno = mno;
	}

    public void print()
	{
		System.out.println("id "+id);
		System.out.println("name "+name);
		System.out.println("Address "+address);
		
	}
	public void printprojects() 
	 { 
	  System.out.println("====STUDENT mobille number========"); 
	  for(Integer project:mno) 
	  { 
	   System.out.println(project); 
	  } 
	 } 

}
