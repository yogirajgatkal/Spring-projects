package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       System.out.println("hello");
       ApplicationContext ctx= new ClassPathXmlApplicationContext("Spconfig.xml");
       DemoBean a =(DemoBean)ctx.getBean("id1");
       a.print();
       a.printprojects();
    }
}
