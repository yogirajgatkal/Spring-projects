package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
       ApplicationContext ctx= new ClassPathXmlApplicationContext("Spconfig.xml");
        RegisterBean a =(RegisterBean)ctx.getBean("id3");
         // a.createtable();
         // a.insertRecord();
         //a.insertRecord();
         //a.deleteRecord();
         a.getallRecord();
         //a.getoneRecords();
    }
}
