package com.yogi;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.jdbc.core.JdbcTemplate;

public class RegisterBean {
	private JdbcTemplate jt;

	public RegisterBean() {
		super();
		// TODO Auto-generated constructor stub
	}

    public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
    public void createtable()
    {
    	jt.execute("create table RegistreBean(id number(10),name varchar2(30),password varchar2(10),email varchar2(30),gender varchar2(10),mobile_no number(20),address varchar2(20),state varchar2(20),city varchar2(20))");
    	System.out.println("new table created");
    }
    public void insertRecord()
	
    {
    	Scanner sc=new Scanner(System.in);
    	
    	System.out.println("enter id");
    	int id=sc.nextInt();
    	
    	System.out.println("enter name");
    	String name=sc.next();
    	
    	System.out.println("enter password");
    	String password=sc.next();
    	
    	System.out.println("enter email");
    	String email=sc.next();
    	
    	System.out.println("enter gender");
    	String gender=sc.next();
    	
    	System.out.println("enter mobile number");
    	Long mobile_no=sc.nextLong();
    	
    	System.out.println("enter address");
    	String address=sc.next();
    	
    	System.out.println("enter state");
    	String state=sc.next();
    	
    	System.out.println("enter city");
    	String city=sc.next();
    	
    	int i=jt.update("insert into RegistreBean values(?,?,?,?,?,?,?,?,?)",id,name,password,email,gender,mobile_no,address,state,city);
        System.out.println(i+"new record insert");	
    }
    public void getallRecord()
    {
		List list=jt.queryForList("select * from RegistreBean");
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Object o=it.next();
			System.out.println(o);
		}
	}
    
}
