package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
       ApplicationContext ctx= new ClassPathXmlApplicationContext("Spconfig.xml");
        additionBean a =(additionBean)ctx.getBean("id2");
        a.print();
    }
}
