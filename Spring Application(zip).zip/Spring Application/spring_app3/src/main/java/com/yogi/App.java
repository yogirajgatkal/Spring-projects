package com.yogi;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println("Hello");
       ApplicationContext ctx= new ClassPathXmlApplicationContext("spconfig.xml");
       ECBean a =(ECBean)ctx.getBean("id1");
       a.bill_Cal();
       a.printInfo();
    }
}

