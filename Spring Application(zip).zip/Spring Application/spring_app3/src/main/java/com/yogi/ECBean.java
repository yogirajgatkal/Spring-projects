package com.yogi;

public class ECBean {
	private int cId,unit=0;
	 private String cName;
	 private int c_reding;
	 private int p_reding;
	 private double total_Bill=0.0;
	// int unit=0;
	 public ECBean() {
	  super();
	  // TODO Auto-generated constructor stub
	 }
	 public ECBean(int cId, String cName, int c_reding, int p_reding) {
	  super();
	  this.cId = cId;
	  this.cName = cName;
	  this.c_reding = c_reding;
	  this.p_reding = p_reding;
	 }
	 public void bill_Cal() {
	  
	  unit =c_reding-p_reding;
	  if(unit<300)
	  {
	   total_Bill=unit*1.75;
	  }
	  else {
	   total_Bill=unit*7.75;
	  }
	 }
	 public void printInfo() {

	  System.out.println("Cust_ID = "+cId);
	  System.out.println("Cust_Name = "+cName);
	  System.out.println("Cust_Current Redding = "+c_reding);
	  System.out.println("Cust_previce Redding = "+p_reding);
	  System.out.println("Total Uint is = "+unit);
	  System.out.println("Total Bill Cost is  = "+total_Bill+" Rs");
	 }
}
