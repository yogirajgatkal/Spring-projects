package com.yogi;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
       ApplicationContext ctx= new ClassPathXmlApplicationContext("Spconfig.xml");
        MobileBean a =(MobileBean)ctx.getBean("id3");
         // a.createtable();
         // a.insertRecord();
         //a.updateRecord();
        //a.deleteRecord();
         a.getRecord();
         //a.getoneRecords();
    }
}
