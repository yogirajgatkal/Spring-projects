package com.yogi;

import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class MobileBean {
	private JdbcTemplate jt;

	public MobileBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	public void createtable()
	{
		jt.execute("create table MobileBean(model_no varchar2(10),model_name varchar2(15),comp_name varchar2(15),ram_size varchar2(10),rom_size varchar2(10),os_name varchar2(15),processor_name varchar2(15),imei_no varchar2(10),f_cam varchar2(10),b_cam varchar2(10),description varchar2(30))");
		System.out.println("table created");
	}
	public void insertRecord()
	{
		//int i=jt.update("insert into MobileBean values('abc123','realme 8s','realme','8Gb','126Gb','Android','xuz','12345z','16Px','64Px','this is realme new mobile')");
		int j=jt.update("insert into MobileBean values('def123','vivo v21','vivo','6Gb','64Gb','Android','xyz','6789z','8Px','64Px','this is vivo new mobile')");
		System.out.println(j+"new record insert");
	}
	public void updateRecord()
	{
		int i=jt.update("update MobileBean set model_name='realme 8S 5G' where comp_name='realme'");
		System.out.println(i+"record updated");
	}
	public void deleteRecord()
	{
		int i=jt.update("delete from MobileBean  where comp_name='realme'");
		System.out.println(i+"record delete");
	}
	public void getRecord()
	{
		List list=jt.queryForList("select * from MobileBean");
		Iterator it=list.iterator();
		while(it.hasNext())
		{
			Object o=it.next();
			System.out.println(o);
		}
	}

}
