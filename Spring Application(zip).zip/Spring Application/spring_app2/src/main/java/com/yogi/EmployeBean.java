package com.yogi;

public class EmployeBean {
	private int eid;
	private String ename;
	private Double salary;
	public EmployeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public void print()
	{
		System.out.print("employe id is :"+eid);
		System.out.print("employe name is :"+ename);
		System.out.print("employe salary is :"+salary);
	}

}
