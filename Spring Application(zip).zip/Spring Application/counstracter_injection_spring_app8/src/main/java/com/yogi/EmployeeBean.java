package com.yogi;

public class EmployeeBean {
	private int id;
	private String name;
	private AddressBean ob;
	public EmployeeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeBean(int id, String name, AddressBean ob) {
		super();
		this.id = id;
		this.name = name;
		this.ob = ob;
	}

	public void print()
	{
		System.out.println("id "+id);
		System.out.println("nameid "+name);
		System.out.println(ob);
		
	}

}
