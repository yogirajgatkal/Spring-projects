package com.yogi;

public class AddressBean {
	private String city;
	private String state;
	public AddressBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AddressBean(String city, String state) {
		super();
		this.city = city;
		this.state = state;
	}
	@Override
	public String toString() {
		return "AddressBean [city=" + city + ", state=" + state + "]";
	}
	

}
