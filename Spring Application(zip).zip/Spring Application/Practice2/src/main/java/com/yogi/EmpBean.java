package com.yogi;

public class EmpBean {
	 private Integer id;
	 private String name;
	 private String address;
	 private String org;
	 public EmpBean() {
		super();
		// TODO Auto-generated constructor stub
	 }
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	@Override
	public String toString() {
		return "EmpBean [id=" + id + ", name=" + name + ", address=" + address + ", org=" + org + "]";
	}
	 
	 public void print()
	 {
		 System.out.println(id);
		 System.out.println(name);
		 System.out.println(address);
		 System.out.println(org);
	 }
	 
	 

}
