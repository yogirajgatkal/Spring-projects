package com.yogi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spconfig.xml");
        EmpBean a=(EmpBean)ctx.getBean("id1");
        a.print();
    }
}
