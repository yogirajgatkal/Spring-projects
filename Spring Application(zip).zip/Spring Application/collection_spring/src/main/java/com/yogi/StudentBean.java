package com.yogi;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class StudentBean {
	
	 private List<String> studentNames; 
	 private Set<Integer> studentRollNumbers; 
	 private Map<String,Integer> branchDetails; 
	 private Properties branchInfos; 
	 //PDC+PSM+PGM+4 business Methods 
	 public StudentBean() { 
	  super(); 
	 } 
	 public List<String> getStudentNames() { 
	  return studentNames; 
	 } 
	 public void setStudentNames(List<String> studentNames) { 
	  this.studentNames = studentNames; 
	 } 
	 public Set<Integer> getStudentRollNumbers() { 
	  return studentRollNumbers; 
	 } 
	 public void setStudentRollNumbers(Set<Integer> studentRollNumbers) { 
	  this.studentRollNumbers = studentRollNumbers; 
	 } 
	 public Map<String, Integer> getBranchDetails() { 
	  return branchDetails; 
	 } 
	 public void setBranchDetails(Map<String, Integer> branchDetails) { 
	  this.branchDetails = branchDetails; 
	 } 
	 public Properties getBranchInfos() { 
	  return branchInfos; 
	 } 
	 public void setBranchInfos(Properties branchInfos) { 
	  this.branchInfos = branchInfos; 
	 } 
	 public void printStudentNames() 
	 { 
	  System.out.println("====STUDENT NAMES========"); 
	  for(String studentName:studentNames) 
	  { 
	   if(studentName.startsWith("s")) 
	   System.out.println(studentName); 
	  } 
	 } 
	 public void printStudentRollNumbers() 
	 { 
	  System.out.println("====STUDENT ROLL NUMBERS========"); 
	  for(Integer studentRollNumber:studentRollNumbers) 
	  { 
	   System.out.println(studentRollNumber); 
	  } 
	 } 
	  
	 public void printBranchDetails() 
	 { 
	  System.out.println("=====BARNCH DETAILS======="); 
	  for(Map.Entry<String, Integer> entry:branchDetails.entrySet()) 
	  { 
	   System.out.println(entry.getKey()+"\t"+entry.getValue()); 
	  } 
	 } 
	  
	 public void printBranchInfo() 
	 { 
	  System.out.println("----------BRANCH INFO ARE------------"); 
	  Set<String> keys = branchInfos.stringPropertyNames(); 
	     for (String key : keys) { 
	       System.out.println(key + "-->" + branchInfos.getProperty(key)); 
	     } 
	 } 
	}

